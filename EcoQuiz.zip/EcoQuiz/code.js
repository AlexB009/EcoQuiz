
console.log(" EcoQuiz started");
var cards = ["1st_card", "2nd_card", "3rd_card", "4th_card", "5th_card", "6th_card", "7th_card", "8th_card", "9th_card", "10th_card"];
var index;
var totalQ = 9;
var correct = 0;
var wrong = 0;
// .

setScreen("home");
function randomQ() {
  console.log("cards= " + cards);
  if (totalQ < 0) {
    setScreen("results");
  } else {
    console.log("index= " + index);
    setScreen(cards[index]);
    removeItem(cards, index);
    totalQ = totalQ - 1;
    console.log("totalQ= " + totalQ);
    return totalQ;
  }
}
onEvent("home_start_btn", "click", function() {
  index = randomNumber(0, totalQ);
  console.log("index= " + index);
  console.log("quiz started");
  totalQ = randomQ(totalQ);
});
onEvent("1st_card_1_btn", "click", function() {
  wrong = wrong + 1;
  setScreen("1st_wrong");
  console.log("btn 1 on card one clicked");
});
onEvent("1st_card_2_btn", "click", function() {
  correct = correct + 1;
  setScreen("1st_right");
  console.log("btn 2 on card one clicke");
});
onEvent("1st_card_3_btn", "click", function() {
  setScreen("1st_wrong");
  console.log("btn 3 on card one clicke");
  wrong = wrong + 1;
});
onEvent("1st_card_4_btn", "click", function() {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("1st_right_next_btn", "click", function() {
  index = randomNumber(0, totalQ);
  totalQ = randomQ(totalQ);
  console.log("next btn1 clicked");
});
onEvent("1st_wrong_next_btn", "click", function() {
  index = randomNumber(0, totalQ);
  totalQ = randomQ(totalQ);
  console.log("wrong next button clicked");
});
onEvent("2nd_card_1_btn", "click", function() {
  setScreen("1st_right");
  console.log("1st button on card 2 clicked");
  correct = correct + 1;
});
onEvent("2nd_card_2_btn", "click", function() {
  setScreen("1st_wrong");
  var wrong = wrong + 1;
  console.log("2nd button on card 2 clicked");
});
onEvent("2nd_card_3_btn", "click", function() {
  setScreen("1st_wrong");
  console.log("3rd btn on card 2 clicked");
  wrong = wrong + 1;
});
onEvent("2nd_card_4_btn", "click", function() {
  setScreen("1st_wrong");
  wrong = wrong + 1;
  console.log("btn 4 on 2nd card clicked");
});
onEvent("2nd_right_next_btn", "click", function() {
  console.log("next q btn on second right click");
  setScreen("3rd_card");
});
onEvent("2nd_wrong_next_btn", "click", function() {
  setScreen("3rd_card");
  console.log("next q btn on second wrong click");
});
onEvent("results_show_btn", "click", function( ) {
  setText("results_show_input", "correct: " + (correct + (" incorrect: " + wrong)));
}); 
//code to append the cards when the restart button is pressed (fixing them)
onEvent("results_try_again_btn", "click", function( ) {
  setText("results_show_input", " ");
  wrong = 0;
  correct = 0;
  totalQ = 9;
  appendItem(cards, "1st_card");
  appendItem(cards, "2nd_card");
  appendItem(cards, "3rd_card");
  appendItem(cards, "4th_card");
  appendItem(cards, "5th_card");
  appendItem(cards, "6th_card");
  appendItem(cards, "7th_card");
  appendItem(cards, "8th_card");
  appendItem(cards, "9th_card");
  appendItem(cards, "10th_card");
  console.log("totalQ= " + totalQ);
  console.log("index= " + index);
  console.log("cards= " + cards);
  setScreen("home");
});
onEvent("3rd_card_2_btn", "click", function( ) {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("3rd_card_1_btn", "click", function( ) {
  setScreen("1st_right");
  correct = correct + 1;
});
onEvent("3rd_card_3_btn", "click", function( ) {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("3rd_card_4_btn", "click", function( ) {
  setScreen("3rd_wrong");
  wrong = wrong + 1;
});
onEvent("3rd_right_next_btn", "click", function( ) {
  setScreen("4th_card");
});
onEvent("3rd_wrong_next_btn", "click", function( ) {
  setScreen("4th_card");
});
onEvent("4th_card_1_btn", "click", function( ) {
  correct = correct + 1;
  setScreen("1st_right");
});
onEvent("4th_card_2_btn", "click", function( ) {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("4th_card_3_btn", "click", function( ) {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("4th_card_4_btn", "click", function( ) {
  wrong = wrong + 1;
  setScreen("1st_wrong");
});
onEvent("4th_right_btn", "click", function( ) {
  setScreen("5th_card");
});
onEvent("4th_wrong_next_btn", "click", function( ) {
  setScreen("5th_card");
});
onEvent("5th_card_2_btn", "click", function( ) {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("5th_card_3_btn", "click", function( ) {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("5th_card_4_btn", "click", function( ) {
  wrong = wrong + 1;
  setScreen("1st_wrong");
});
onEvent("5th_card_1_btn", "click", function( ) {
  correct = correct + 1;
  setScreen("1st_right");
});
onEvent("5th_wrong_next_btn", "click", function( ) {
  setScreen("6th_card");
});
onEvent("5th_right_next_btn", "click", function( ) {
  setScreen("6th_card");
});
onEvent("6th_card_1_btn", "click", function( ) {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("6th_card_2_btn", "click", function( ) {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("6th_card_3_btn", "click", function( ) {
  setScreen("1st_right");
  correct = correct + 1;
});
onEvent("6th_card_4_btn", "click", function( ) {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("6th_right_next_btn", "click", function( ) {
  setScreen("7th_card");
});
onEvent("6th_wrong_next_btn", "click", function( ) {
  setScreen("7th_card");
});
onEvent("7th_card_1_btn", "click", function( ) {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("7th_card_2_btn", "click", function( ) {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("7th_card_3_btn", "click", function( ) {
  setScreen("1st_wrong");
  wrong = wrong + 1;
});
onEvent("7th_card_4_btn", "click", function( ) {
  setScreen("1st_right");
  correct = correct + 1;
});
onEvent("7th_right_next_btn", "click", function( ) {
  setScreen("8th_card");
});
onEvent("7th_wrong_next_btn", "click", function( ) {
  setScreen("8th_card");
});
onEvent("8th_card_1_btn", "click", function( ) {
  wrong = wrong + 1;
  setScreen("1st_wrong");
});
onEvent("8th_card_2_btn", "click", function( ) {
  correct = correct + 1;
  setScreen("1st_right");
});
onEvent("8th_card_3_btn", "click", function( ) {
  wrong = wrong + 1;
  setScreen("1st_wrong");
});
onEvent("8th_card_4_btn", "click", function( ) {
  wrong = wrong + 1;
  setScreen("1st_wrong");
});
onEvent("8th_right_next_btn", "click", function( ) {
  setScreen("9th_card");
});
onEvent("8th_wrong_btn", "click", function( ) {
  setScreen("9th_card");
});
onEvent("9th_card_1_btn", "click", function( ) {
  wrong = wrong + 1;
  setScreen("1st_wrong");
});
onEvent("9th_card_2_btn", "click", function( ) {
  wrong = wrong + 1;
  setScreen("1st_wrong");
});
onEvent("9th_card_3_btn", "click", function( ) {
  correct = correct + 1;
  setScreen("1st_right");
});
onEvent("9th_card_4_btn", "click", function( ) {
  wrong = wrong + 1;
  setScreen("1st_wrong");
});
onEvent("9th_right_next_btn", "click", function( ) {
  setScreen("10th_card");
});
onEvent("9th_wrong_next_btn", "click", function( ) {
  setScreen("10th_card");
});
onEvent("10th_card_4_btn", "click", function( ) {
  correct = correct + 1;
  setScreen("1st_right");
});
onEvent("10th_card_2_btn", "click", function( ) {
  wrong = wrong + 1;
  setScreen("1st_wrong");
});
onEvent("10th_card_3_btn", "click", function( ) {
  wrong = wrong + 1;
  setScreen("1st_wrong");
});
onEvent("10th_card_1_btn", "click", function( ) {
  wrong = wrong + 1;
  setScreen("1st_wrong");
});
onEvent("learn_button", "click", function( ) {
  setScreen("screen1");
});
